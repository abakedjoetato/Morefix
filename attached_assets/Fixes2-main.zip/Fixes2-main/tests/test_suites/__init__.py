"""
Test Suites Package for Tower of Temptation PvP Statistics Bot

This package contains test suites for different parts of the bot:
- SFTP commands
- Error handling
- Canvas commands
- And more
"""